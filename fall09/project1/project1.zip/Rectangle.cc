#include "Rectangle.h"
#include "Point.h" 

Rectangle::Rectangle (Point *p, double width, double length) {

   this -> p = p;
   this -> width = width;
   this -> length = length;
}
