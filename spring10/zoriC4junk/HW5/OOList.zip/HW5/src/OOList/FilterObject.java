package OOList;
/**
 * Filter object class.
 * 
 * @author Zori Babroudi
 * 
 */
public class FilterObject {
	
	FilterObject (int nn, Alist nL)
	{
		n = nn;
		L = nL;
	}
	
	int n;
	Alist L;
	
}