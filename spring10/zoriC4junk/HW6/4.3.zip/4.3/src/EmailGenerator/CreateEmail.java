package EmailGenerator;
import java.io.*;

/**
 * Student Email Creator : Assignment 4.3
 * @author Zori Babroudi
 */
public class CreateEmail {

	/**
	 * 
	 * @param Input file must be Students.txt
	 */
	public static void main(String[] args) {
		String line;
		try {
			File infile = new File("Students.txt");
			File outfile = new File("Studentemail.txt");

			BufferedReader in = new BufferedReader(new FileReader(infile));
			PrintWriter out = new PrintWriter(new BufferedWriter(
					new FileWriter(outfile)));
			while ((line = in.readLine()) != null) {

				String temp[] =	line.split(":");
				String temp2 = temp[1].substring(0, 1).toLowerCase() + temp[0].substring(0, 1).toLowerCase() + temp[2].substring(5, 9) + "@student.uml.edu";

				//System.out.println(temp2);
				out.println(temp2);
			}
			
			System.out.println("Finished creating Studentemail.txt from Students.txt.");
			
			in.close();
			out.close();
		} catch (FileNotFoundException e) {
			System.out.println(e);
		} catch (IOException e) {
			System.out.println(e);
		}
	}
}
