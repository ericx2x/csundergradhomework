package Car;

/**
 * SuperClass for Aassignments 8.2 and 8.3.
 * @author Zori Babroudi
 */
public class Car {
	
	private String Model;
	private String Manufacturer;
	private String Color;
	private int YR;
	private int HP;
	private int Cyl;

	/**
	 * 
	 * @param m - Manufacturer
	 */
	public void set_Manufacturer (String m) { Manufacturer = m; }
	
	/**
	 * 
	 * @param m - Model Name
	 */
	public void set_Model (String m) { Model = m; }
	
	/**
	 * 
	 * @param c - Color
	 */
	public void set_Color (String c) { Color = c; }
	
	/**
	 * 
	 * @param y - Model Year
	 */
	public void set_YR (int y) { YR = y; }
	
	/**
	 * 
	 * @param h - Horse Power
	 */
	public void set_HP (int h) { HP = h; }
	
	/**
	 * 
	 * @param n - Number of Cylinders
	 */
	public void set_Cyl (int n) { Cyl = n; }
	
	/* Getters */
	
	/**
	 * 
	 * @return Manufacturer
	 */
	public String get_Manufacturer () { return(Manufacturer); }
	
	/**
	 * 
	 * @return Model
	 */
	public String get_Model () { return(Model); }
	
	/**
	 * 
	 * @return Color
	 */
	public String get_Color () { return(Color); }
	
	/**
	 * 
	 * @return Model Year
	 */
	public int get_YR () { return(YR); }
	
	/**
	 * 
	 * @return Horse Power
	 */
	public int get_HP () { return(HP); }
	
	/**
	 * 
	 * @return Number of Cylinders
	 */
	public int get_Cyl () { return(Cyl); }
	
	/* Constructor */
	
	/**
	 * 
	 * @param Man - The Manufacturer
	 * @param Mod - Model Name
	 * @param Col - Color
	 * @param Y - Model Year
	 * @param H - Horse Power
	 * @param C - Number of Cylinders
	 */
	public Car (String Man, String Mod, String Col, int Y, int H, int C) {
		
		set_Manufacturer (Man);
		set_Model (Mod);
		set_Color (Col);
		set_YR (Y);
		set_HP (H);
		set_Cyl (C);
	
	}

	public String toString()
	{
		
		String temp  = new String (
				"{" +
				Manufacturer + ", " +
				Model + ", " +
				Color + ", " +
				YR + ", " +
				"\n" + HP + "-HP, " + 
				Cyl + "-Cylinder " +
				"}\n");
	
	
		return temp;
	
	}
}
