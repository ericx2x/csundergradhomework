package Car;
import java.util.Comparator;

/**
 * Comparator for assignment 8.2
 * @author Zori Babroudi
 */
public class Compare implements Comparator<Car>{

	/**
	 * Compare function.
	 * @param arg0 a Car
	 * @param arg1 a Car
	 * @return 1 if arg0 > arg1, 0 if arg0 = arg1, -1 if arg0 < arg1
	 */
	public int compare(Car arg0, Car arg1) {
		
		if (arg0.get_Manufacturer().compareTo(arg1.get_Manufacturer()) > 0)
			{ return 1; }
		
		else if (arg0.get_Manufacturer().equals(arg1.get_Manufacturer()))
		{
			
			if (arg0.get_Model().compareToIgnoreCase(arg1.get_Model()) > 0)
				return 1;
			
			else if (arg0.get_Model().equals(arg1.get_Model()))
			{
			
				if (arg0.get_YR() > arg1.get_YR())
					return 1;
				
				else if (arg0.get_YR() == arg1.get_YR())
					return 0;
				
				else 
					return -1;
				
			
			} else {
				
				return -1;
				
			}
			
			
		}
		
		//if c1.Manufacturer < c2.Manufacturer
		return -1;
		
	}
	
	

}
