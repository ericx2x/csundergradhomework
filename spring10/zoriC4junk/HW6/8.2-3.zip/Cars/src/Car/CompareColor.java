package Car;
import java.util.Comparator;

/**
 * Compare by Color ascending
 * @author Zori Babroudi
 *
 */
public class CompareColor implements Comparator<Car>{
	
	private int case1 = 1;
	private int case2 = 0;
	private int case3 = -1;
	
	public int compare (Car arg0, Car arg1) {
		
		if (arg0.get_Color().compareTo(arg1.get_Color()) > 1)
		{
			return case1;
		}
		
		else if (arg0.get_Color().equals(arg1.get_Color()))
		{
			return case2;
		}
		
		return case3;
		
	}

}
