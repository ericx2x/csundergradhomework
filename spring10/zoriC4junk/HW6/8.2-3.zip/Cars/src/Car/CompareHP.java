package Car;
import java.util.Comparator;

/**
 * Compare by HP descending
 * @author Zori Babroudi
 *
 */
public class CompareHP implements Comparator<Car>{
	
	private int case1 = 1;
	private int case2 = 0;
	private int case3 = -1;
	
	public int compare (Car arg0, Car arg1) {
		
		if (arg0.get_HP() > arg1.get_HP())
		{
			return case1;
		}
		
		else if (arg0.get_HP() == arg1.get_HP())
		{
			return case2;
		}
		
		return case3;
		
	}

}