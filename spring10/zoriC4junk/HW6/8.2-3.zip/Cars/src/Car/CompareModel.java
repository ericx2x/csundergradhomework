package Car;
import java.util.Comparator;

/**
 * Compare by Model ascending
 * @author Zori Babroudi
 *
 */
public class CompareModel implements Comparator<Car>{
	
	private int case1 = 1;
	private int case2 = 0;
	private int case3 = -1;
	
	public int compare (Car arg0, Car arg1) {
		
		if (arg0.get_Model().compareTo(arg1.get_Model()) > 1)
		{
			return case1;
		}
		
		else if (arg0.get_Model().equals(arg1.get_Model()))
		{
			return case2;
		}
		
		return case3;
		
	}

}