package Car;
import java.util.*;

/**
 * Main class for assignment 8.2
 * @author Zori Babroudi
 */
public class SortCars {

	/**
	 * @param args takes in nothing.
	 */
	public static void main(String[] args) {
		
		List<Car> list1 = new LinkedList<Car>();

		list1.add(new Car("Toyota", "Corolla", "Grey", 2009, 130, 4));
		list1.add(new Car("Acura", "Integra", "Red", 2009, 120, 4));
		list1.add(new Car("GM", "Cadilac", "Black", 2003, 420, 8));
		list1.add(new Car("Saturn", "Vibe", "Silver", 2008, 140, 4));

		System.out.println("Before Sorting:\n");
		for( Iterator<Car> i = list1.iterator(); i.hasNext(); ) 
		{
		
			System.out.println("- " + i.next().toString());
		
		}
		
		Collections.sort(list1, new Compare());
		
		System.out.println("\nAfter Sorting:\n");
		for( Iterator<Car> i = list1.iterator(); i.hasNext(); ) 
		{
		
			System.out.println("- " + i.next().toString());
			
		}	

	}

}

