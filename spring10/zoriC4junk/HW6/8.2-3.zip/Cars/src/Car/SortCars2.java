package Car;
import java.util.*;

/**
 * Main class for assignment 8.3
 * @author Zori Babroudi
 */
public class SortCars2 {

	/**
	 * @param args takes type ascending/descending.
	 */
	public static void main(String[] args) {

		boolean descending = false;

		List<Car> list1 = new LinkedList<Car>();

		list1.add(new Car("Acura", "Integra", "Red", 2009, 120, 4));
		list1.add(new Car("GM", "Cadilac", "Black", 2003, 420, 8));
		list1.add(new Car("BMW", "Series 5", "Black", 2005, 500, 6));
		list1.add(new Car("Saturn", "Vibe", "Silver", 2008, 140, 4));
		list1.add(new Car("Toyota", "Corolla", "Grey", 2009, 130, 4));
		
		if (args[0].equals("Manufacturer"))
		{

			Collections.sort(list1, new CompareManufacturer());

			if (args[1].equals("descending"))
				descending = true;	

		}
		else if (args[0].equals("Model"))
		{

			Collections.sort(list1, new CompareModel());

			if (args[1].equals("descending"))
				descending = true;

		}
		else if (args[0].equals("Color"))
		{

			Collections.sort(list1, new CompareColor());

			if (args[1].equals("descending"))
				descending = true;

		}
		else if (args[0].equals("Year"))
		{

			Collections.sort(list1, new CompareYR());

			if (args[1].equals("descending"))
				descending = true;

		}
		else if (args[0].equals("HP"))
		{

			Collections.sort(list1, new CompareHP());

			if (args[1].equals("descending"))
				descending = true;

		}
		else if (args[0].equals("Cylinder"))
		{

			Collections.sort(list1, new CompareCyl());

			if (args[1].equals("descending"))
				descending = true;

		} else {

			Collections.sort(list1, new Compare());

		}

		System.out.println("\nSorted by: " + args[0] + ", " + args[1] + "\n");


		if (descending == true)
		{

			List<Car> list2 = new LinkedList<Car>();

			for( int i = 0; i < list1.size(); ++i) 
			{

				list2.add(list1.listIterator(list1.size()-1-i).next());

			}

			for( Iterator<Car> i = list2.iterator(); i.hasNext(); ) 
			{

				System.out.println("- " + i.next().toString());

			}

		}else {

			for( Iterator<Car> i = list1.iterator(); i.hasNext(); ) 
			{

				System.out.println("- " + i.next().toString());

			}

		}

	}

}

